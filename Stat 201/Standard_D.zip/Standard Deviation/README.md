# Statistics program to calculate Standard Deviation and other shit for class;
## using std=c++11

1. find `makefile`
2. run *nix command `make` in same dir as `makefile`
3. run *nix command `make clean` when done.

